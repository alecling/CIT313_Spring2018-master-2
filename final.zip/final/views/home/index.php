<?php
include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">
    <h1>IUPUI CIT313 Final Project</h1>
  </div>

    <img src="<?php echo BASE_URL?>views/img/tech.jpg" alt="img" width="1500"/>
		<h2>Alexa's Final Project</h2>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra, sapien sed lacinia pharetra, nibh orci congue felis, sit amet bibendum dolor tellus eget mi. Nullam sit amet ligula at quam dignissim tempus at at neque. Cras id massa orci. Nulla congue velit eget pulvinar molestie. Vivamus ullamcorper rutrum dolor sit amet congue. In fermentum enim laoreet pharetra sagittis. Ut vestibulum eget ligula et sollicitudin. Vestibulum sed arcu dapibus, porta turpis sit amet, venenatis felis. Cras et facilisis turpis. Integer quis interdum nulla.

		</p>


</div>
<?php include('views/elements/footer.php');?>
