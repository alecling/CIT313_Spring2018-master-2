<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21441/CIT313/a4/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'alecling');
define('DB_PASS', 'alecling');
define('DB_NAME', 'alecling_db');
